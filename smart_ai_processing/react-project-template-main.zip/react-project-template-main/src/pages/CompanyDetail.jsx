const CompanyDetail = () => {
  return (
    <section>
      <div className="h-screen flex justify-center items-center">
        <h1>Halaman Company Detail</h1>
      </div>
    </section>
  );
};

export default CompanyDetail;
