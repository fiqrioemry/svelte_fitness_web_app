const EmployerJobs = () => {
  return (
    <section>
      <div className="h-screen flex justify-center items-center">
        <h1>Halaman Employer Jobs</h1>
      </div>
    </section>
  );
};

export default EmployerJobs;
