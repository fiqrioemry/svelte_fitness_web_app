const EmployerApplications = () => {
  return (
    <section>
      <div className="h-screen flex justify-center items-center">
        <h1>Halaman Employer Applications</h1>
      </div>
    </section>
  );
};

export default EmployerApplications;
