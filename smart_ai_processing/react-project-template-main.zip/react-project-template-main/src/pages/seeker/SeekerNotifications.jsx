const SeekerNotifications = () => {
  return (
    <section>
      <div className="container mx-auto overflow-y-hidden">
        <div className="h-[80vh] flex items-center justify-center">
          <div className="space-y-4 text-center">
            <h4>You Dont have Notifications</h4>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SeekerNotifications;
